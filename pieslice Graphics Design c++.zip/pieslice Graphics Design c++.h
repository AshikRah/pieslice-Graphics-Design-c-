#include <graphics.h>
int main()
{
    int a=DETECT;
    int b,i,j;
    initgraph(&a,&b,"c:\\tc\\bgi");
    int x=getmaxx()/2;
    int y=getmaxy()/2;
for(i=0;i<=200;i++)
{
    setcolor(RED);
    setfillstyle(SOLID_FILL,RED);
    pieslice(200,0+i-50,60,120,50);
    setcolor(GREEN);
    setfillstyle(SOLID_FILL,GREEN);
    pieslice(400-i,250,60,120,100);
    setcolor(YELLOW);
    setfillstyle(SOLID_FILL,YELLOW);
    pieslice(0+i,400,60,120,150);
    delay(10);
    if(i<200)
    {

    cleardevice();
    }

}
  delay(30);
    arc(254.9,277.5,60,180,60);
    circle(280,235,10);
    arc(147.9,277.5,0,120,60);
    circle(120,235,10);
    getch();
    closegraph();

}

